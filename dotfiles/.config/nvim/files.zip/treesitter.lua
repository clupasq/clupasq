return {
  {
    "nvim-treesitter/nvim-treesitter",
    build = ":TSUpdate",
    dependencies = {
      -- Textobjects — replaces vim-angry (argument text objects)
      --               and the coc funcobj/classobj mappings
      "nvim-treesitter/nvim-treesitter-textobjects",
    },
    config = function()
      require("nvim-treesitter.configs").setup({
        ensure_installed = {
          "javascript", "typescript", "tsx",
          "python", "lua",
          "json", "yaml", "toml",
          "html", "css",
          "bash", "vim", "vimdoc",
          "markdown", "markdown_inline",
          "haskell",
        },
        auto_install = true,
        highlight = { enable = true },
        indent    = { enable = true },

        textobjects = {
          select = {
            enable = true,
            lookahead = true,  -- jump forward to next match
            keymaps = {
              -- Argument text objects — replaces vim-angry (ia / aa)
              ["ia"] = "@parameter.inner",
              ["aa"] = "@parameter.outer",
              -- Function text objects — replaces coc-funcobj
              ["if"] = "@function.inner",
              ["af"] = "@function.outer",
              -- Class text objects — replaces coc-classobj
              ["ic"] = "@class.inner",
              ["ac"] = "@class.outer",
            },
          },
          move = {
            enable = true,
            set_jumps = true,
            goto_next_start     = { ["]m"] = "@function.outer" },
            goto_previous_start = { ["[m"] = "@function.outer" },
          },
        },
      })
    end,
  },
}
